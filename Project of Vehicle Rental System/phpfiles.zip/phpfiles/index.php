<!--IT20129576 J.K.M Dulaj Thiwanka-->
<?php
	session_start();

	if (!isset($_SESSION['username'])) {
		$_SESSION['msg'] = "You must log in first";
		header('location: login.php');
	}

	if (isset($_GET['logout'])) {
		session_destroy();
		unset($_SESSION['username']);
		header("location: login.php");
	}

?>

<!DOCTYPE html>

<html>
     <head>
		<title>Rental Vehicle System</title>
		<link rel="stylesheet" href="..\css\styles.css">
		<link rel="script" href="..\js\new.js">
	 </head>
     <body style="background-image:url('../images/photo.jpg')">

<hr class="hr1">
	<table class="tab1" style="width:100%" border=0px>
	<tr>
	<td class="td1"><center><img src="../images/logo.png" style="width:120px;height:120px;" alt="logo" ></center></td>
	<td class="td2"><h3>&nbsp;&nbsp;&nbsp;RENTA Vehicle.LK</h3></td>
	<td class="td3"><center><strong><?php echo $_SESSION['username']; ?></strong></center></td>
	<div class="set">
	</div>
	<td class="td1"><a href="UserAcc.php"><center><img src="../images/new.png" style="width:120px;height:120px;" alt="profile"></center></a></td>
	</tr>
	</table>



<!------------------------------------------------------------------------------------------------>


		<div class="newslayout">
			<a href="index.php">HOME</a>
			<a href="self.php">RENT</a>
			<!--a href="vehicle.php" class="b1" type="button" id="button1" onclick="loadData('button1')">VEHICLE</a-->
			<a href="contactus.php">CONTACT US</a>
			<a href="about_us.php">ABOUT US</a>
			<a href="UserAcc.php">MY PROFILE</a>
			<div class="search">

				<!--<div id="user"><i class="fa fa-user"></i></div>-->
				<input type="text" placeholder="Search">
				<label class="fa fa-search input-icon"></label>

				</div>
			</div>
		</div>
	<br>
<!------------------------------------------------------------------------------------------------>
<hr class="hr1">
<div class="slider">
</div>
<br>
<br>
<!------------------------------------------------------------------------------------------------>

<hr class="hr1">
<br>
<table class="tab1" style="width:100%" border=0px>
<tr>
<td style="width:500px"><font class="contact"><mark>Contact Us:</font></mark></td>
<td rowspan="11" colspan="3" style="width:200px"></td>

<td rowspan="11"><a href="https://www.facebook.com/"><center><img src="../images/fb.png" style="width:60px" alt="FB" class="p1"></a></center></td>
<td rowspan="11"><a href="https://www.Twitter.com/"><center><img src="../images/tw.png" style="width:60px" alt="Twitter" class="p1"></a></center></td>
<td rowspan="11"><a href="https://www.Instagram.com/"><center><img src="../images/insta.png" style="width:60px" alt="Insta" class="p1"></center></a></td>
<td rowspan="11"><a href="https://www.Gmail.com/"><center><img src="../images/mail.png" style="width:60px" alt="Mail" class="p1"></a></center></td>


</tr>
<tr>
</tr>
<tr>
<td><font class="ta"><br>&nbsp;&nbsp;&nbsp;<b>No.234 ,</b></font></td>
</tr>
<tr>
<td><font class="ta">&nbsp;&nbsp;&nbsp;<b>Kandy Rd ,</b></font></td>
</tr>
<tr>
<td><font class="ta">&nbsp;&nbsp;&nbsp;<b>Kelaniya ,Sri Lanka</b></font></td>

</tr>
<tr>
<td>&nbsp;</td>

</tr>
<tr>
<td><font class="ta">&nbsp;&nbsp;&nbsp;<b>Hotline:</b></font></td>

</tr>
<tr>
<td><font class="ta">&nbsp;&nbsp;&nbsp;<b>076-4465200</b></font></td>

</tr>
<tr>
<td><font class="ta">&nbsp;&nbsp;&nbsp;<b>011-7775550</b></font></td>

</tr>
<tr>
<td>&nbsp;</td>

</tr>
<tr>
<td><font class="ta">&nbsp;&nbsp;&nbsp;<b>Email:rentavehicle@gmail.com</b></font></td>
</tr>
</p>

</table>

<hr class="hr1">

<!------------------------------------------------------------------------------------------------>


	 </body>
</html>
<!--IT20129576 J.K.M Dulaj Thiwanka-->
