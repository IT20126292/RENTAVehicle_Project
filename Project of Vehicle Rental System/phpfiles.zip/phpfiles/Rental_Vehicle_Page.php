<!--IT20129576 J.K.M Dulaj Thiwanka-->
<!DOCTYPE html>

<html>
     <head>
		<title>Rental Vehicle System</title>
		<link rel="stylesheet" href="..\css\styles.css">
		<link rel="script" href="..\js\new.js">
	 </head>
     <body style="background-image:url('../images/photo.jpg')" onload=display_ct();>

<hr class="hr1">
	<table class="tab1" style="width:100%" border=0px>
	<tr>
	<td class="td1"><center><img src="../images/logo.png" style="width:120px;height:120px;" alt="logo" ></center></td>
	<td class="td2"><h3>&nbsp;&nbsp;&nbsp;RENTA Vehicle.LK</h3></td>
	<td class="td3">
	&nbsp;&nbsp;&nbsp;&nbsp;
	<td><a href="home.html" class="bb"><button class="btn" type="button" id="reg"><b>Login</b></a></button></td>
	<div class="set">
	<td><a href="register.html" class="bb"><button class="btn" type="button" id="reg"><b>Register</b></a></button></td>
	</div>
	</td>
	<td class="td1"><a href="UserAcc.html"><center><img src="../images/new.png" style="width:120px;height:120px;" alt="profile"></center></a></td>
	</tr>
	 </table>



<!------------------------------------------------------------------------------------------------>


		<div class="newslayout">
			<a href="index.php" disabled>HOME</a>
			<a href="self.php" class="b1" type="button" id="button1" onclick="loadData('button1')">RENT</a>
			<a href="Rental_Vehicle_Page.php">VEHICLES</a>
			<a href="contactus.php">CONTACT US</a>
			<a href="about_us.html">ABOUT US</a>
			<a href="UserAcc.php">MY PROFILE</a>
			<div class="search">


				<input type="text" placeholder="Search">
				<label class="fa fa-search input-icon"></label>

				</div>
			</div>
		</div>

<!------------------------------------------------------------------------------------------------>
	<br>



	<div class="container2">
	<center>
	
<p><marquee><b>Available Vehicles...</b> </marquee></p>
<br>


<table border="1" style="width:100%">
<tr>
<td>

<table border="1" height="300" width="660" >
 <tr>
    <td  rowspan="2"><img src="C:\Users\Infonet Computers\Downloads\Vehicle Rental System (It_20187132)\Images\USC80BMS201A021001.jpg" 
alt image=height="150" width="250" style= "float:center; margin-right:0px; margin-bottom:5px;" /></td>
    <td  rowspan="2"><u><font color="red">The BMW X3 </font>is a compact luxury crossover SUV manufactured by German automaker BMW since 2003..</u><br>
<br>
BMW X3 Colours. BMW X3 is available in 4 different colours <br>
<b>[Mineral White, Phytonic Blue, Sophisto Grey Brilliant Effect, Black Sapphire]</b><br>
<br>
*Leather int.A/C<br>
*Mood Lighting,Bluetooth<br>
*Power Steering<br>
*FIVE Passenger/Seating Capacity<br>
*Without Driver Only</td>
    <td><center>Hrs.1 10km - 3000/=</center></td>
  </tr>
  <tr>
    <td><button type="button">Book Now</button></td>
	
 
  </tr>
  </td>
  </tr>
  </table>
  <br>
  
  
<td>
<table border="1" height="300" width="660" >
 <tr>
    <td  rowspan="2"><img src="C:\Users\Infonet Computers\Downloads\Vehicle Rental System (It_20187132)\Images\BEZZA_BACK_LEFT_.jpg" 
alt image=height="150" width="250" style= "float:center; margin-right:0px; margin-bottom:5px;" /></td>
    <td  rowspan="2"><u>The <font color="red">PERODUA BEZZA</font> is produced by Malaysian automobile manufacturer Perodua in 2016</u></p><br>
Perodua Bezza 2020 is available in 6 different colors.<br>
<b>[Ocean Blue, Ivory White Solid, Sugar Brown, Glittering Silver Metallic, Granite Grey and Garnet Red Metallic.]</b></br>
<br>
*Perodua Bezza Prime Sedan A/C.<br>
*Power Steering <br>
*CD Player <br>
*Auto gear<br>
*With Driver/Without Driver</td>
    <td><center>Hrs.1 10km - 1000/=</center></td>
  </tr>
  <tr>
    <td><button type="button"> Book Now</button></td>
 
  </tr>
  </td>
  </tr>
  </table>
  <br>
  
  
  
    <tr>
    <td><table border="1" height="300" width="660" >
 <tr>
    <td  rowspan="2"><img src="C:\Users\Infonet Computers\Downloads\Vehicle Rental System (It_20187132)\Images\HILUX-SUPER-WHITE.jpg" 
alt image=height="150" width="250" style= "float:center; margin-right:0px; margin-bottom:5px;" /></td>
    <td  rowspan="2"><u>The <font color="red">TOYOTA HILUX </font>is produced and marketed by the Japanese automobile manufacturer Toyota.</u></p><br>
Toyota Hilux is available in six different colors.<br>
<b>[Crystal Pearl,Glacier White,Silver Sky, Graphite,Eclipse Black and Nebula Blue]</b></br>
<br>
*Lockable Flat Fibre Canopy<br>
*A/C,CD Player<br>
*Power Steering<br>
*manual<br>
*With Driver/Without Driver</td>
    <td><center>Hrs.1  10km - 1500/=</center></td>
  </tr>
  <tr>
    <td><button type="button"> Book Now</button></td>
 
  </tr>
  </td>
  </tr>
  </table>
  

  
  
    <td>
<table border="1" height="300" width="660" >
 <tr>
    <td  rowspan="2"><img src="C:\Users\Infonet Computers\Downloads\Vehicle Rental System (It_20187132)\Images\10102070_200808.jpg" 
alt image=height="150" width="250" style= "float:center; margin-right:0px; margin-bottom:5px;" /></td>
    <td  rowspan="2"><u>The <font color="red">TOYOTA ALPHARD </font>is a minivan produced by the Japanese automaker Toyota since 2002.</u></p><br>
Alphard 3.5L V6 Executive Lounge | Brand New Luxury Van has two colours.<br>
<b>[White,Black]</b></br>
<br>
*Driver + 6 Passenger<br>
*Multi A/C<br>
*Auto,Mp3 Player<br>
*With Driver/Without Driver</td>
    <td><center>Hrs.1 10km - 2500/=</center></td>
  </tr>
  <tr>
    <td><button type="button"> Book Now</button></td>
 
  </tr>
  </td>
  </table>
   </table>
   

	</p>
	</table>

	</div>

	</div>
</table>
 <br>
    <br>
	  <br>
	    <br>
		   <br>
<footer>
<!------------------------------------------------------------------------------------------------>
<table style="border:0px solid black;margin-top:60px">
<br>
<hr class="hr1"><br>
      <table class="tab2" style="width:100%;" border=0px >
	  <tr>

	  <td style="width:40px";><center><a href="https://www.facebook.com/"><img src="../images/fb.png" style="width:30px;" alt="fb" class="footerph"></a></center></td>
	  <td style="width:40px";><center><a href="https://www.Twitter.com/"><img src="../images/tw.png" style="width:30px" alt="fb" class="footerph"></a></center></td>
	  <td style="width:40px";><a href="https://www.Instagram.com/"><center><img src="../images/insta.png" style="width:30px" alt="fb" class="footerph"></a></center></td>
	  <td style="width:40px";><a href="https://mail.google.com/mail/u/0/?tab=km#inbox"><center><img src="../images/mail.png" style="width:30px" alt="fb" class="footerph"></center></td>
	  <td style="width:300px"></div></td>
	  <td style="width:40px";><font size="04" style="float:right"><b><center>Hotline:0764465200</b></font></center></td>
	  <td style="width:50px"></td>
	  </tr>
	  </table>
	<!--<hr class="hr1">-->
</table>

</footer>
<!------------------------------------------------------------------------------------------------>
	 </body>
</html>
<!--IT20129576 J.K.M Dulaj Thiwanka-->
