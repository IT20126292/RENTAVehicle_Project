<!--IT20129576 J.K.M Dulaj Thiwanka-->
<!DOCTYPE html>

<html>
     <head>
		<title>Rental Vehicle System</title>
		<link rel="stylesheet" href="..\css\styles.css">
		<link rel="script" href="..\js\new.js">
	 </head>
     <body style="background-image:url('../images/photo.jpg')">

<hr class="hr1">
	<table class="tab1" style="width:100%" border=0px>
	<tr>
	<td class="td1"><center><img src="../images/logo.png" style="width:120px;height:120px;" alt="logo" ></center></td>
	<td class="home_td2"><h1>&nbsp;&nbsp;&nbsp;RENTA Vehicle.LK</h1></td>
	<td class="td3">
	&nbsp;&nbsp;&nbsp;&nbsp;
	<td><a href="SignIn.php" class="bb"><button class="btn" type="button" id="reg"><b>Login</b></a></button></td>
	<div class="set">
	<td><a href="register.php" class="bb"><button class="btn" type="button" id="reg"><b>Register</b></a></button></td>
	</div>
	</td>
	<td class="td1"><a href="UserAcc.html"><center><img src="../images/new.png" style="width:120px;height:120px;" alt="profile"></center></a></td>
	</tr>
	 </table>



<!------------------------------------------------------------------------------------------------>


		<div class="newslayout">
			<a href="home.php">HOME</a>
			<!--a href="vehicle.html" class="b1" type="button" id="button1" onclick="loadData('button1')">VEHICLE</a-->
			<!--a href="contactus.php">CONTACT US</a>
			<a href="about_us.php">ABOUT US</a-->
			<div class="search">

				<!--<div id="user"><i class="fa fa-user"></i></div>-->
				<input type="text" placeholder="Search">
				<label class="fa fa-search input-icon"></label>

				</div>
			</div>
		</div>
	<br>
<!------------------------------------------------------------------------------------------------>
<hr class="hr1">
<div class="slider">
</div>
<br>
<br>
<!------------------------------------------------------------------------------------------------>

<hr class="hr1">
<br>
<table class="tab1" style="width:100%" border=0px>
<tr>
<td style="width:500px"><font class="contact"><mark>Contact Us:</font></mark></td>
<td rowspan="11" colspan="3" style="width:200px"></td>

<td rowspan="11"><a href="https://www.facebook.com/"><center><img src="../images/fb.png" style="width:60px" alt="FB" class="p1"></a></center></td>
<td rowspan="11"><a href="https://www.Twitter.com/"><center><img src="../images/tw.png" style="width:60px" alt="Twitter" class="p1"></a></center></td>
<td rowspan="11"><a href="https://www.Instagram.com/"><center><img src="../images/insta.png" style="width:60px" alt="Insta" class="p1"></center></a></td>
<td rowspan="11"><a href="https://www.Gmail.com/"><center><img src="../images/mail.png" style="width:60px" alt="Mail" class="p1"></a></center></td>


</tr>
<tr>
</tr>
<tr>
<td><font class="ta"><br>&nbsp;&nbsp;&nbsp;<b>426/6</b></font></td>
</tr>
<tr>
<td><font class="ta">&nbsp;&nbsp;&nbsp;<b>Mankada Rd,</b></font></td>
</tr>
<tr>
<td><font class="ta">&nbsp;&nbsp;&nbsp;<b>Kadawatha,Sri Lanka</b></font></td>

</tr>
<tr>
<td>&nbsp;</td>

</tr>
<tr>
<td><font class="ta">&nbsp;&nbsp;&nbsp;<b>Hotline:</b></font></td>

</tr>
<tr>
<td><font class="ta">&nbsp;&nbsp;&nbsp;<b>076-4465200</b></font></td>

</tr>
<tr>
<td><font class="ta">&nbsp;&nbsp;&nbsp;<b>011-2921380</b></font></td>

</tr>
<tr>
<td>&nbsp;</td>

</tr>
<tr>
<td><font class="ta">&nbsp;&nbsp;&nbsp;<b>Email:Rentavehicle@gmail.com</b></font></td>
</tr>
</p>

</table>

<hr class="hr1">

<!------------------------------------------------------------------------------------------------>


	 </body>
</html>
<!--IT20129576 J.K.M Dulaj Thiwanka-->
