<!DOCTYPE html>
<?php include('server.php') ?>

<html>
     <head>
		<title>Vehicle Rental System</title>
		<link rel="stylesheet" href="..\css\styles1.css">
		<script type="text/javascript" src="../js/myScript.js">
		</script>
		<meta name="viewport" content="width=device-width, initial-scale=1">
	 </head>
      <body style="background-image:url('../images/photo.jpg')" onload=display_ct();>

	<hr class="hr1">
			<table class="tab1" style="width:100%" border=0px>
				<tr>
					<td class="td1"><center><img src="../images/logo.png" style="width:150px;height:150px;" alt="logo"></center></td>
					<td class="td2"><h3>&nbsp;&nbsp;&nbsp;RENTA VEHICLE.LK</h3></td>
					<td class="td3">
					&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
					<td><a href="SignIn.php" class="bb"><button class="btn" type="button" id="reg"><b>Login</b></a></button></td>
		<div class="set">
		<td><a href="register.php" class="bb"><button class="btn" type="button" id="reg"><b>Register</b></a></button></td>
		</div>
	</td>
					<td class="td1"><a href="UserAcc.php"><center><img src="../images/new.png" style="width:120px;height:120px;" alt="profile"></center></a></td>
				</tr>
			</table>


<!------------------------------------------------------------------------------------------------>

			<div class="newslayout">
			<a href="home.php">HOME</a>
			<!--a href="vehicle.php" class="b1" type="button" id="button1" onclick="loadData('button1')">VEHICLES</a-->
			<a href="contact.php">CONTACT US</a>
			<a href="about_us.php">ABOUT US</a>
				<div class="search">
					<input type="text" placeholder="Search">
					<label class="fa fa-search input-icon"></label>
				</div>
			</div>
			<br>
<!------------------------------------------------------------------------------------------------>
<table class="regi12" style="width:100%" border="0px">
			<tr>
				<td>
					<div class="slider">
					<br><br><br>
	<center>
						<div class="container">
              	<form method="post" action="Signin.php">
                  <?php include('errors.php'); ?>
		<center>
			<table class="regi" border="0px">
				<tr>
				</tr>
				<tr >
					<td style="font-size:30px;font-weight:bold;"><u><center>User Login</center></u></td>
				</tr>
				<td  style="width:47%">&nbsp;</td>
				<tr>
					<p class="newfont">
				</tr>
				<tr>
					<td><center><input type="text" placeholder=" Username" class="fbin" name="username"></center></td>
				</tr>
					<td>&nbsp;</td>
				<tr>
					<td><center><input type="password" placeholder=" Password"  class="psin" name="password"></center></td>
				</tr>
				<tr>
					<td><a href="forgotPassword.php" class="fpd">Forgot Password?</a></td>
				</tr>
				<tr>
				</tr>
				<tr>
					<td><br><button type="submit" class="sign0" name="login_user" style="margin-right:80px;">Sign In</button></td>
				</tr>
				<tr>
					<td><br><Button class="sign1" style="margin-right:80px;"><a href="register.php" style="text-decoration:none;">Create New Account</a></button></td>
				</tr>
		</center>

			</p>
		</table>

		</div>

		</div>
  </form>
	</center>
</table>
<!------------------------------------------------------------------------------------------------>
<br>
<!------------------------------------------------------------------------------------------------>
	</div>
	</td>
</tr>
</table>
<br>
<footer>
<hr class="hr1"><br>
<Table style="width:100%" class="k1">
<th class="x1">
<table style="border:0px solid black;margin-top:50px">
<!--<hr class="hr1"><br>-->
      <table class="tab2" style="width:100%;" border=0px >
	  <tr>
	  <center>
	  <td><center><a href="https://www.facebook.com/"><img src="../images/fb.png" style="width:30px" alt="fb" class="p1" id="fb"></a></center></td>
	  <td><center><a href="https://www.Twitter.com/"><img src="../images/tw.png" style="width:30px" alt="fb" class="p1" id="fb"></a></center></td>
	  <td><center><a href="https://www.Instagram.com/"><img src="../images/insta.png" style="width:30px" alt="fb" class="p1" id="fb"></a></center></td>
	  <td><center><a href="https://www.Gmail.com/"><img src="../images/mail.png" style="width:30px" alt="fb" class="p1" id="fb"></a></center></td>
	  <td style="width:400px"></td>
	  <td><font size="04" style="float:right"><b><center>Hotline:0764465200</b></font></center></td>
	  <td style="width:40px"></td>
	  </tr>
	  <tr>
		<td></td>
		<td></td>
		<td></td>
		<td></td>
		<td></td>
		<td>
			<script class="data">
			var currentDate = new Date();
			var month = currentDate.getMonth()+1;
			var day = currentDate.getDate();
			var year = currentDate.getFullYear();
			var fullDate = month + "/" + day + "/" + year;
			document.write(fullDate);
		</script>
		</td>
		<td></td>
	  </tr>
	  </table>
	<!--<hr class="hr1">-->
</table>
</th>
</table>
</footer>

<!------------------------------------------------------------------------------------------------>

 	 </body>
</html>
