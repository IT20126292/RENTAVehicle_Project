<!DOCTYPE html> 
<?php include('server.php') ?>
<html>
     <head>           
		<title>User Account Page</title>  
		<link rel="stylesheet" href="..\css\styles1.css">
		<script type="text/javascript" src="../js/myScript.js">
		</script>
		<meta name="viewport" content="width=device-width, initial-scale=1">
		<style>
			input14[type=submit] {
			  background-color: #4CAF50;
			  color: white;
			}
			#message {
			  display:none;
			  background: #f1f1f1;
			  color: #000;
			  position: relative;
			  padding: 20px;
			  margin-top: -15px;
			}

			#message p {
			  padding: 5px 40px;
			  font-size: 16px;
			}

			.valid {
			  color: green;
			}

			.valid:before {
			  position: relative;
			  left: -20px;
			  content: "✔";
			}

			.invalid {
			  color: red;
			}

			.invalid:before {
			  position: relative;
			  left: -20px;
			  content: "✖";
			  }
			  
			 .container12{
				position:static;
				border-radius:15px;
				background-color: #f2f2f2;
				margin-top: 30px;
				margin-bottom: 10px;
				margin-right: 5%;
				margin-left: 5%;
				padding: 15px 0 15px 0;
				width:100%;
				margin-right: 0px;
				margin-left: 0px;
				background-image:url("../images/div1.jpg");
				}
			
		</style>
	 </head>
     <body style="background-image:url('../images/photo.jpg')" onload=display_ct();>
	 
		<hr class="hr1">
			<table class="tab1" style="width:100%" border=0px>
				<tr>
					<td class="td5"><center><img src="../images/logo.png" style="width:150px;height:150px;" alt="logo" ></center></td>
					<td class="td6"><h3>&nbsp;&nbsp;&nbsp;RENTA VEHICLE.LK</h3></td>
					<td class="td7"></td>
					&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
					<!--td><button class="btn" type="button" id="log"><b>Login</b></button></td-->
					<!--td style="width:100px"><label for="CustomerName" class="h2">CUSTOMER's NAME</label></td-->
					<!--td class="td5"><label for="CustomerName" class="h2" id="log" class="fbincn">CUSTOMER's NAME</label></td-->
						<!--div class="set">
							<td><button class="btn" type="button" id="reg"><b>Register</b></button></td>
						</div-->
					<!--/td-->
					<td class="td9"><strong><?php echo $_SESSION['username']; ?></strong></td>
					<td class="td8"><center><a href="UserAcc.html"><img src="../images/new.png" style="width:120px;height:120px;" alt="logo" ></a></center></td>
				</tr>
			</table>
	 
	 
<!------------------------------------------------------------------------------------------------>	 	
		
			<div class="newslayout">
				<a href="index.php">HOME</a>
				<a href="self.php">RENT</a>
				<a href="vehicle.php" class="b1" type="button" id="button1" onclick="loadData('button1')">VEHICLES</a>
				<a href="contactus.php">CONTACT US</a>
				<a href="about_us.php">ABOUT US</a>
				<a href="UserAcc.php">MY PROFILE</a>
				<div class="search">
					<input type="text" placeholder="Search">
					<label class="fa fa-search input-icon"></label>
				</div>
			</div>
			<br>
<!------------------------------------------------------------------------------------------------>
	<form action="/action_page.php" action="/JavaScript/Index" onsubmit="return checkPassword()">	
		<div class="profile_container12">
			<table style="width:100%;height:500px" border="0px">
				<tr>
					<td rowspan=7 class="td10"><center><a href="UserAcc.html"><img src="../images/new.png" style="width:140px;height:160px;" class="dpeditor" alt="logo" ></a></center></td>
					<td rowspan=7 style="width:1%"><div class="vl"></div></td>
					<td colspan=2 class="td11"><h6>&nbsp;&nbsp;&nbsp;My Profile</h6></td>
				</tr>

				<tr>
					<td class="td12">
						<label for="firstname" class="h10">First Name:</label><br>
						<input type="text" id="fname" name="fname" class="input12" placeholder="<?php echo $_SESSION['username']; ?>" required>
					</td>
					<td>
						<label for="firstname" class="h10">Last Name:</label><br>
						<input type="text" id="fname" name="fname" class="input12" placeholder="Silva" required>
					</td>

				</tr>

				<tr>
					<td class="td12">
						<label for="firstname" class="h10">Username:</label><br>
						<input type="text" id="fname" name="fname" class="input12" placeholder="<?php echo $_SESSION['username']; ?>" required>
					</td>
					<td>
						<label for="firstname" class="h10">E-mail Address:</label><br>
						<input type="email" id="mail" name="mail" class="input13" placeholder="<?php echo $_SESSION['email']; ?>" pattern="[a-z0-9._%+-]+@[a-z0-9.-]+\.[a-z]{2,3}$" required>
					</td>

				</tr>

				<tr>
					<td class="td12">
						<label for="firstname" class="h10">Mobile Number:</label><br>
						<input type="tel" id="mnum" name="mnum" class="input12" placeholder="012-345-6789"  pattern="[0-9]{3}[0-9]{3}[0-9]{4}" maxlength="10" required>
					</td>
					<td>
						<label for="repsw" class="h10">Current Password:</label><br>
						<input type="password" id="repsw" name="repsw" class="input12" placeholder="**********" title="Please enter your current password" maxlength="10" required><br>
					</td>

				</tr>
				
				<tr>
					<td>
						<label for="psw" class="h10">Re-enter Password:</label><br>
						<input type="password" id="psw" name="psw" class="input12" pattern="(?=.*\d)(?=.*[a-z])(?=.*[A-Z]).{5,10}" maxlength="10" placeholder="**********" title="Please enter new password" required>
						
						<div id="message">
								<h3>Password must contain the following:</h3>
								<p id="letter" class="invalid"><b>A lowercase letter</b></p>
								<p id="capital" class="invalid"><b>A capital (uppercase) letter</b></p>
								<p id="number" class="invalid"><b> A number</b></p>
								<p id="length" class="invalid"><b>Minimum 5 characters</b></p>
								<p id="lengths" class="invalid"><b>Maximum 10 characters</b></p>
						</div><br>
						
						<script>
			var myInput = document.getElementById("psw");
			var letter = document.getElementById("letter");
			var capital = document.getElementById("capital");
			var number = document.getElementById("number");
			var length = document.getElementById("length");
			var length1 = document.getElementById("lengths");

			myInput.onfocus = function() {
			  document.getElementById("message").style.display = "block";
			}

			myInput.onblur = function() {
			  document.getElementById("message").style.display = "none";
			}

			myInput.onkeyup = function() 
			{
			  var lowerCaseLetters = /[a-z]/g;
				  if(myInput.value.match(lowerCaseLetters)) 
				  {  
					letter.classList.remove("invalid");
					letter.classList.add("valid");
				  } 
				  else 
				  {
					letter.classList.remove("valid");
					letter.classList.add("invalid");
				  }
			  
			  var upperCaseLetters = /[A-Z]/g;
				  if(myInput.value.match(upperCaseLetters)) 
				  {  
					capital.classList.remove("invalid");
					capital.classList.add("valid");
				  } 
				  else 
				  {
					capital.classList.remove("valid");
					capital.classList.add("invalid");
				  }

			  var numbers = /[0-9]/g;
				  if(myInput.value.match(numbers)) 
				  {  
					number.classList.remove("invalid");
					number.classList.add("valid");
				  } 
				  else 
				  {
					number.classList.remove("valid");
					number.classList.add("invalid");
				  }
			  
				  if(myInput.value.length >= 5) 
				  {
					length.classList.remove("invalid");
					length.classList.add("valid");
				  } 
				  else 
				  {
					length.classList.remove("valid");
					length.classList.add("invalid");
				  }
			  
				  if(myInput.value.length == "10") 
				  {
					length1.classList.remove("invalid");
					length1.classList.add("valid");
				  } 
				  else 
				  {
					length1.classList.remove("valid");
					length1.classList.add("invalid");
				  }
			}
			
			function checkPassword(){
				var myInput1 = document.getElementById("psw");
				var myInput2 = document.getElementById("repsw");
				
				if(myInput1.value == myInput2.value){
					alert("Password Mismatch!");  
					return true;
				}else{
					alert("Success!");
					return false;
				}
	
			}
		</script>
					</td>
					<td></td>

				</tr>
				
				<tr>
						<td></td>
						<div class="set">
							<td class="td12">
								<!--button class="btn123" type="button" id="sav"><a href="SignIn.html"><b>Save Changes</b></a></button-->
								<input type="submit" value="Save Changes" class="input14" id="sav">
							</td>
						</div>

				</tr>
				
				<tr>
						<td></td>
						<td></td>
				</tr>


			</table>
		</div>
	</form>
<!------------------------------------------------------------------------------------------------>
<br>
<footer>
<hr class="hr1"><br>
<Table style="width:100%" class="k1">
<th class="x1">
<table style="border:0px solid black;margin-top:50px">
<!--<hr class="hr1"><br>-->

      <table class="tab2" style="width:100%;" border=0px >
	  <tr>
	  <center>
	  <td><center><a href="https://www.facebook.com/"><img src="../images/fb.png" style="width:30px" alt="fb" class="p1" id="fb"></a></center></td>
	  <td><center><a href="https://www.Twitter.com/"><img src="../images/tw.png" style="width:30px" alt="tw" class="p1" id="tw"></a></center></td>
	  <td><center><a href="https://www.Instagram.com/"><img src="../images/insta.png" style="width:30px" alt="insta" class="p1" id="insta"></a></center></td>
	  <td><center><a href="https://www.Gmail.com/"><img src="../images/mail.png" style="width:30px" alt="mail" class="p1" id="mail"></a></center></td>
	  <td style="width:400px"></td>
	  <td><font size="04" style="float:right"><b><center>Hotline:0764465200</b></font></center></td>
	  <td style="width:40px"></td>
	  </tr>
	  </table>
	<!--<hr class="hr1">-->
</table>
</th>
</table>
</footer>

<!------------------------------------------------------------------------------------------------>
 
	 </body>
</html>