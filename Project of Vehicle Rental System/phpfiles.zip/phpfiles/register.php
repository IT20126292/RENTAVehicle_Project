<!--IT20129576 J.K.M Dulaj Thiwanka-->
<?php include('server.php') ?>
<!DOCTYPE html>

<html>
     <head>
		<title>Rental Vehicle System</title>
		<link rel="stylesheet" href="..\css\styles.css">
		<link rel="script" href="..\js\new.js">
	 </head>
     <body style="background-image:url('../images/photo.jpg')" onload=display_ct();>

<hr class="hr1">
	<table class="tab1" style="width:100%" border=0px>
	<tr>
	<td class="td1"><center><img src="../images/logo.png" style="width:120px;height:120px;" alt="logo" ></center></td>
	<td class="register_td2"><h1>&nbsp;&nbsp;&nbsp;RENTA Vehicle.LK</h1></td>
	<td class="td3">
	&nbsp;&nbsp;&nbsp;&nbsp;
	<td><a href="SignIn.php" class="bb"><button class="btn" type="button" id="reg"><b>Login</b></a></button></td>
	<div class="set">
	<td><a href="register.php" class="bb"><button class="btn" type="button" id="reg"><b>Register</b></a></button></td>
	</div>
	</td>
	<td class="td1"><a href="UserAcc.php"><center><img src="../images/new.png" style="width:120px;height:120px;" alt="profile"></center></a></td>
	</tr>
	 </table>



<!------------------------------------------------------------------------------------------------>


		<div class="newslayout">
			<a href="home.php">HOME</a>
			<!--a href="vehicle.php" class="b1" type="button" id="button1" onclick="loadData('button1')">VEHICLES</a-->
			<a href="contactus.php">CONTACT US</a>
			<a href="about_us.php">ABOUT US</a>
			<div class="search">


				<input type="text" placeholder="Search">
				<label class="fa fa-search input-icon"></label>

				</div>
			</div>
		</div>

<!------------------------------------------------------------------------------------------------>
	<br>


	<form method="post" action="register.php">
    <?php include('errors.php'); ?>
	<div class="container">
	<center>
	<table class="regi" border="0px">
		<tr>
			<td style="width:47%">&nbsp;</td>
			<td style="width:6%" rowspan="9"><center><button class="or" disabled><b>Or</b></button></center></td>
			<td  style="width:47%">&nbsp;</td>

		</tr>
		<tr >
			<td style="font-size:27px;font-weight:bold;"><center>Register For an account</center></td>

			<td style="font-size:30px;font-weight:bold;"><center>Sign in with Your<br>Social Account</center></td>

		</tr>
		<tr>
			<td>&nbsp;</td>

			<td>&nbsp;</td>
			<p class="newfont">
		</tr>
		<tr>
			<td><center><input type="text" placeholder="Full Name" name="username" class="fbin" value="<?php echo $username; ?>"></center></td>

			<td><center><button class="facebook">Login With Facebook<br></button></center></td>

		</tr>
		<tr>
			<td><center>	<input type="email" name="email" placeholder="Email" class="emin" value="<?php echo $email; ?>"></center></td>

			<td><center><br><button class="twitter">Login With Twitter</button><center></td>

		</tr>
		<tr>
			<td><center><br><input type="password" name="password_1" class="psin" placeholder="Password"></center></td>
        <td><center><br><Button class="google">Login With Google</button></center></td>
    <tr>
      <td><center><input type="password" name="password_2" class="rpsin" placeholder="Retype Password"></center></td>

			<td><center><br><Button class="google" style="opacity:0%"></button></center></td>

		</tr>
		<tr>
			<td>&nbsp;</td>

			<td>&nbsp;</td>

		</tr>

		<tr>
			<td><br><button type="submit" class="sign" name="reg_user" style="margin:10px;">Sign In</button></input></td>

			<td>
      </td>

		</tr>
	</center>

	</p>
	</table>

	</div>

	</div>
</form>
</table>
<footer>
<!------------------------------------------------------------------------------------------------>
<table style="border:0px solid black;margin-top:60px">
<br>
<hr class="hr1"><br>
      <table class="tab2" style="width:100%;" border=0px >
	  <tr>

	  <td style="width:40px";><center><a href="https://www.facebook.com/"><img src="../images/fb.png" style="width:30px;" alt="fb" class="footerph"></a></center></td>
	  <td style="width:40px";><center><a href="https://www.Twitter.com/"><img src="../images/tw.png" style="width:30px" alt="fb" class="footerph"></a></center></td>
	  <td style="width:40px";><a href="https://www.Instagram.com/"><center><img src="../images/insta.png" style="width:30px" alt="fb" class="footerph"></a></center></td>
	  <td style="width:40px";><a href="https://mail.google.com/mail/u/0/?tab=km#inbox"><center><img src="../images/mail.png" style="width:30px" alt="fb" class="footerph"></center></td>
	  <td style="width:300px"></div></td>
	  <td style="width:40px";><font size="04" style="float:right"><b><center>Hotline:0764465200</b></font></center></td>
	  <td style="width:50px"></td>
	  </tr>
	  </table>
	<!--<hr class="hr1">-->
</table>

</footer>
<!------------------------------------------------------------------------------------------------>
 <function>
	 </body>
</html>
<!--IT20129576 J.K.M Dulaj Thiwanka-->
