<!--IT20129576 J.K.M Dulaj Thiwanka-->
<?php include('server.php') ?>
<!DOCTYPE html>

<html>
     <head>
		<title>Rental Vehicle System</title>
		<link rel="stylesheet" href="..\css\styles.css">
		<link rel="stylesheet" href="..\css\styles1.css">
		<link rel="stylesheet" href="..\css\cont_us.css">
		<link rel="script" href="..\js\new.js">
	 </head>
     <body style="background-image:url('../images/photo.jpg')" onload=display_ct();>

<hr class="hr1">
	<table class="tab1" style="width:100%" border=0px>
	<tr>
	<td class="td1"><center><img src="../images/logo.png" style="width:120px;height:120px;" alt="logo" ></center></td>
	<td class="td2"><h3>&nbsp;&nbsp;&nbsp;RENTA Vehicle.LK</h3></td>
	<td class="td3">
	&nbsp;&nbsp;&nbsp;&nbsp;
	<td><a href="SignIn.php" class="bb"><button class="btn" type="button" id="reg"><b>Login</b></a></button></td>
	<div class="set">
	<td><a href="register.html" class="bb"><button class="btn" type="button" id="reg"><b>Register</b></a></button></td>
	</div>
	</td>
	<td class="td1"><a href="UserAcc.html"><center><img src="../images/new.png" style="width:120px;height:120px;" alt="profile"></center></a></td>
	</tr>
	 </table>



<!------------------------------------------------------------------------------------------------>


		<div class="newslayout">
			<a href="index.php">HOME</a>
			<a href="self.php">RENT</a>
			<!--a href="vehicle.php" class="b1" type="button" id="button1" onclick="loadData('button1')">VEHICLES</a-->
			<a href="contactus.php">CONTACT US</a>
			<a href="about_us.php">ABOUT US</a>
			<a href="UserAcc.php">MY PROFILE</a>
			<div class="search">


				<input type="text" placeholder="Search">
				<label class="fa fa-search input-icon"></label>

				</div>
			</div>
		</div>

<!------------------------------------------------------------------------------------------------>

	<form action="/action_page.php" action="/JavaScript/Index" onsubmit="return checkPassword()">	
		<div class="contactus_container12">
		<h1 style="background-color:red;border-radius:10px;height:50px;">&nbsp;&nbsp;&nbsp;Contact US For Any Enquiry</h1>
			<table style="width:100%;height:500px" border="0px" class="contacttable">
				<tr>
					<td rowspan=4 class="contact_td10">
						<div id="wrapper-9cd199b9cc5410cd3b1ad21cab2e54d3">
							<div id="map-9cd199b9cc5410cd3b1ad21cab2e54d3"></div>
							<script>
								(function () {
									var setting = {"height":400,"width":900,"zoom":6.2,"queryString":"Sri Lanka Foundation Institute, Independence Square, Colombo, Sri Lanka","place_id":"ChIJy2oxsBFZ4joRqVJWzM9WHxM","satellite":false,"centerCoord":[6.906875682956945,79.86026876667995],"cid":"0x131f56cfcc5652a9","lang":"en","cityUrl":"/sri-lanka/colombo-19459","cityAnchorText":"Map of Colombo, Colombo District, Sri Lanka","id":"map-9cd199b9cc5410cd3b1ad21cab2e54d3","embed_id":"293858"};
									var d = document;
									var s = d.createElement('script');
									s.src = 'https://1map.com/js/script-for-user.js?embed_id=293858';
									s.async = true;
									s.onload = function (e) {
									window.OneMap.initMap(setting)
									};
									var to = d.getElementsByTagName('script')[0];
									to.parentNode.insertBefore(s, to);
									})();
							</script>
						</div>
					</td>
					<td rowspan=5 style="width:2%">
						<div class="vl">
						</div>
					</td>
					<td colspan=1 class="contact_td11"><b>&nbsp;&nbsp;MAIL US</b></td>
				</tr>

				<tr>
					<td class="contact_td121">
						<!--label for="firstname" class="h10">Last Name:</label><br-->
						<input type="email" id="mail" name="mail" class="contact_input12" placeholder="From:" pattern="[a-z0-9._%+-]+@[a-z0-9.-]+\.[a-z]{2,3}$" required>
					</td>

				</tr>

				<tr>
					<td class="contact_td121">
						<!--label for="firstname" class="h10">E-mail Address:</label><br-->
						<input type="email" id="mail" name="mail" class="contact_input13" placeholder="To:" pattern="[a-z0-9._%+-]+@[a-z0-9.-]+\.[a-z]{2,3}$" required>
					</td>

				</tr>

				<tr>
					<td class="contact_td121">
						<!--label for="repsw" class="h10">Current Password:</label><br-->
						<textarea id="repsw" name="repsw" rows="6" cols="70" class="contact_input12" placeholder="Type your Message Here:" required></textarea>
					</td>
				</tr>
				
				<tr>
					<td>
						<div class="contact_contactusdiv">
							<label class="contact_con_address"><img src="../images/location.png" style="width:25px;height:25px;" class="contact_posi_icon"><b>&nbsp;No.234,Kandy Rd,Kelaniya<b></label>&nbsp;&nbsp;&nbsp;&nbsp;
							<label class="contact_con_email"><img src="../images/emailus.png" style="width:25px;height:25px;" class="contact_posi_icon"><b>&nbsp;rentavehicle@gmail.com</b></label>&nbsp;&nbsp;&nbsp;&nbsp;
							<label class="contact_con_phoneno"><img src="../images/callus.png" style="width:25px;height:25px;" class="contact_posi_icon"><b>&nbsp;011-7775550</b></label>
						</div>
					</td>
					<div class="contact_set">
							<td class="contact_td12">
								<!--button class="btn123" type="button" id="sav"><a href="SignIn.html"><b>Save Changes</b></a></button-->
								<input type="submit" value="Submit" class="contact_input14" id="sav">
							</td>
					</div>
				</tr>
			</table>
		</div>
	</form>

<!------------------------------------------------------------------------------------------------>

<footer>
<table style="border:0px solid black;margin-top:60px">
<br>
<hr class="hr1"><br>
      <table class="tab2" style="width:100%;" border=0px >
	  <tr>

	  <td style="width:40px";><center><a href="https://www.facebook.com/"><img src="../images/fb.png" style="width:30px;" alt="fb" class="footerph"></a></center></td>
	  <td style="width:40px";><center><a href="https://www.Twitter.com/"><img src="../images/tw.png" style="width:30px" alt="fb" class="footerph"></a></center></td>
	  <td style="width:40px";><a href="https://www.Instagram.com/"><center><img src="../images/insta.png" style="width:30px" alt="fb" class="footerph"></a></center></td>
	  <td style="width:40px";><a href="https://mail.google.com/mail/u/0/?tab=km#inbox"><center><img src="../images/mail.png" style="width:30px" alt="fb" class="footerph"></center></td>
	  <td style="width:300px"></div></td>
	  <td style="width:40px";><font size="04" style="float:right"><b><center>Hotline:0764465200</b></font></center></td>
	  <td style="width:50px"></td>
	  </tr>
	  </table>
	<!--<hr class="hr1">-->
</table>

</footer>
<!------------------------------------------------------------------------------------------------>
 <function>
	 </body>
</html>
<!--IT20129576 J.K.M Dulaj Thiwanka-->
